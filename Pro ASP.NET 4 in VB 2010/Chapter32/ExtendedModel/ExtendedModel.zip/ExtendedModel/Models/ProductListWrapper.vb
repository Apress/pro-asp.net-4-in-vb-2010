﻿Namespace ExtendedModel.Models

    Public Class ProductListWrapper
        Public Property Product() As Product
        Public Property SelectedSupplier() As String
        Public Property SelectedCategory() As String
    End Class
End Namespace

