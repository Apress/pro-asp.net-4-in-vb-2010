﻿Imports System.ComponentModel.DataAnnotations

Namespace ExtendedModel.Models

    <MetadataType(GetType(Product.ProductMetaData))>
    Partial Public Class Product

        Public Class ProductMetaData
            <Range(1, 50)>
            Public Property UnitsInStock() As Object
        End Class
    End Class
End Namespace

